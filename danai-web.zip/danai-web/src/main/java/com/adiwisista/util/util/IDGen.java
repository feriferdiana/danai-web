/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adiwisista.util.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
 *
 * @author iBas
 */
public class IDGen {

    public static String generate() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static String generateTrxId(String virtualAccount) {
        //Max length 14
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Date now = new Date();
        //Setelah concat, max length = 30
        return sdf.format(now).concat(virtualAccount);
    }

    public static String generateTrxIdDoku(String virtualAccount) {
        //Max length 14
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
        Date now = new Date();
        //Setelah concat, max length = 30
        return sdf.format(now).concat(virtualAccount);
    }
}
