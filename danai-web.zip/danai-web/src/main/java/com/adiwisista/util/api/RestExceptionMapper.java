package com.adiwisista.util.api;

import org.eclipse.microprofile.rest.client.ext.ResponseExceptionMapper;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

@Provider
public class RestExceptionMapper implements ResponseExceptionMapper<RuntimeException>{
    @Override
    public RuntimeException toThrowable(Response rspns) {
        return new WebApplicationException(rspns);
    }
}
