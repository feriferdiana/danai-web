package com.adiwisista.util.json;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;

/**
 *
 * @author iBas
 */
public class Json {

    private static Json instance;
    private final ObjectMapper objectMapper;
    private final ObjectReader reader;
    private final ObjectWriter writer;

    public static Json getInstance() {
        if (instance == null) {
            instance = new Json();
        }
        return instance;
    }

    private Json() {
        objectMapper = new ObjectMapper()
                .configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
                .configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, false);
        JaxbAnnotationModule jaxbModule = new JaxbAnnotationModule();
        objectMapper.registerModule(jaxbModule);
        reader = objectMapper.reader();
        writer = objectMapper.writer();
    }

    public static ObjectReader getReader() {
        return getInstance().reader;
    }

    public static ObjectWriter getWriter() {
        return getInstance().writer;
    }

    public static ObjectMapper objectMapper() {
        return getInstance().objectMapper;
    }

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public static String fromJsonWithKey(String json, String key) {
        try {
            JsonNode root = objectMapper().readTree(json);
            return root.get(key).asText();
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static byte[] toJsonByte(Object value) {
        try {
            return getWriter().writeValueAsBytes(value);
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static String toJson(Object value) {
        try {
            return getWriter().writeValueAsString(value);
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static String toJsonPretty(Object value) {
        try {
            return getWriter().withDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static <T> T fromJson(String json, Class<T> tClass) {
        try {
            return getReader().forType(tClass).readValue(json);
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static <T> T fromJson(String json, TypeReference<T> typeReference) {
        try {
            return getReader().forType(typeReference).readValue(json);
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static <T> T fromJson(String json, String rootName, Class<T> tClass) {
        try {
            JsonNode jsonNode = objectMapper().readTree(json);
            return getReader().forType(tClass).readValue(jsonNode.get(rootName));
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static <T> T fromJson(String json, String rootName, TypeReference<T> typeReference) {
        try {
            JsonNode jsonNode = objectMapper().readTree(json);
            return getReader().forType(typeReference).readValue(jsonNode.get(rootName));
        } catch (Exception e) {
            e.printStackTrace();
            throw new IllegalArgumentException(e.getMessage(), e.getCause());
        }
    }

    public static void changeValueTree(JsonNode parent, String fieldName, String newValue) {
        if (parent.has(fieldName)) {
            ((ObjectNode) parent).put(fieldName, newValue);
        }

        // Now, recursively invoke this method on all properties
        for (JsonNode child : parent) {
            changeValueTree(child, fieldName, newValue);
        }
    }
}
