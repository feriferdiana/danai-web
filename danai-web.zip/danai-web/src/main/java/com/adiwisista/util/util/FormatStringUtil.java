package com.adiwisista.util.util;

import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.collect.Iterables;

import javax.enterprise.context.ApplicationScoped;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.TreeMap;

@ApplicationScoped
public class FormatStringUtil {

    private final static TreeMap<Integer, String> map = new TreeMap<Integer, String>();

    static {

        map.put(1000, "M");
        map.put(900, "CM");
        map.put(500, "D");
        map.put(400, "CD");
        map.put(100, "C");
        map.put(90, "XC");
        map.put(50, "L");
        map.put(40, "XL");
        map.put(10, "X");
        map.put(9, "IX");
        map.put(5, "V");
        map.put(4, "IV");
        map.put(1, "I");

    }

    public static String toRoman(int number) {
        int l = map.floorKey(number);
        if (number == l) {
            return map.get(number);
        }
        return map.get(l) + toRoman(number - l);
    }

    public static String separateDashString(String text) {
        if (Strings.isNullOrEmpty(text)) {
            return "-";
        }
        Iterable<String> result = Splitter.fixedLength(4).split(text);
        String[] parts = Iterables.toArray(result, String.class);

        String formatText = "";
        int iterator = 0;
        for (String s : parts) {
            formatText = formatText.concat(s);
            if (iterator < parts.length - 1) {
                formatText = formatText.concat("-");
            }
            iterator++;
        }
        return formatText;
    }

    public static String formatAmount(BigDecimal bil) {
        if (bil == null) {
            return "-";
        }
        DecimalFormatSymbols decimalSymbols = DecimalFormatSymbols.getInstance();
        decimalSymbols.setDecimalSeparator(',');
        decimalSymbols.setGroupingSeparator('.');
        DecimalFormat decimalFormat = new DecimalFormat("###,###.##", decimalSymbols);
        return decimalFormat.format(bil);
    }

    public static String formatLoanRequest(String loanRequest) {
        if (!Strings.isNullOrEmpty(loanRequest)) {
            int interval = 4;
            char separator = '-';
            StringBuilder sb = new StringBuilder(loanRequest);
            for (int i = 0; i < loanRequest.length() / interval; i++) {
                sb.insert(((i + 1) * interval) + i, separator);
            }
            String maskedLoanRequest = sb.toString();
            return maskedLoanRequest;
        } else {
            return "";
        }
    }

    public static String generateJatuhTempo(String jatuhTempo) {
        String tahun = jatuhTempo.substring(0, 4);
        String bulan = jatuhTempo.substring(4, 6);
        String result = jatuhTempo;

        switch (Integer.parseInt(bulan)) {
            case 1:
                result = "Januari " + tahun;
                break;
            case 2:
                result = "Februari " + tahun;
                break;
            case 3:
                result = "Maret " + tahun;
                break;
            case 4:
                result = "April " + tahun;
                break;
            case 5:
                result = "Mei " + tahun;
                break;
            case 6:
                result = "Juni " + tahun;
                break;
            case 7:
                result = "Juli " + tahun;
                break;
            case 8:
                result = "Agustus " + tahun;
                break;
            case 9:
                result = "September " + tahun;
                break;
            case 10:
                result = "Oktober " + tahun;
                break;
            case 11:
                result = "November " + tahun;
                break;
            case 12:
                result = "Desember " + tahun;
                break;
            default:
                break;
        }
        return result;
    }


    public static String generateTokenPln(String tokenPln) {
        String result = "";
        if (!Strings.isNullOrEmpty(tokenPln)) {
            String trimmedToken = tokenPln.trim();
            Iterable<String> pieces = Splitter.fixedLength(4).split(trimmedToken);
            int i = 1;
            for (String s : pieces) {
                if (i == 1) {
                    result = s;
                    i++;
                } else {
                    result = result + " " + s;
                }
            }
        }
        return result;
    }
}
