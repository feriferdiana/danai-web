package com.adiwisista.util.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.MultivaluedMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapUtils {

    private static final Logger LOG = LoggerFactory.getLogger(MapUtils.class);

    public static Map<String, Object> generateToMap(MultivaluedMap<String, String> request){
        Map<String,Object> value = new HashMap<>();
        Iterator<String> it = request.keySet().iterator();
        while(it.hasNext()){
            String theKey = it.next();
            value.put(theKey,request.getFirst(theKey));
        }

        return value;
    }

    public static Map<String, Object> removeUndescore(Map<String, Object> map){
        Map<String,Object> newMap = new HashMap<>();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String newKey = "";
            String[] stringArr = entry.getKey().split("_");
            int index = 0;
            for(String value : stringArr){
                if(index > 0){
                    String firstLetter = value.substring(0, 1);
                    firstLetter = firstLetter.toUpperCase();
                    String secondLetter = value.substring(1);

                    value = firstLetter + secondLetter;
                }

                newKey += value;

                index++;
            }

            newMap.put(newKey, entry.getValue());
        }

        return newMap;
    }
}