package com.adiwisista.util.encryptor;

import com.google.common.hash.Hashing;
import org.apache.commons.codec.digest.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class EncryptorUtils {
    // String value = "clientId + email";

    public static String toMD5(String value) {
        return DigestUtils.md5Hex(value);
    }

    public static String toSHA256(String value){
        return Hashing.sha256()
                .hashString(value, StandardCharsets.UTF_8)
                .toString();
    }
}