package com.adiwisista.util.util;

public interface FilterGenerator {
    FilterItem createFilterItem(String fieldName, Object valueStr);
}
