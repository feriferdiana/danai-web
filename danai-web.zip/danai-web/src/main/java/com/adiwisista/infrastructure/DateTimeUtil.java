/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.adiwisista.infrastructure;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Months;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
/**
 *
 * @author Nealson William
 */

@ApplicationScoped
public class DateTimeUtil {

    private final static Logger LOG = LoggerFactory.getLogger(DateTimeUtil.class);
    private final static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private final static String DATE_FORMAT_DDMMMYYYY = "dd-MMM-yyyy";
    private final static String DATE_FORMAT_DDMMMYYYYHHmmss = "dd-MMM-yyyy HH:mm:ss";
    private final static String DATE_FORMAt_YYMMDD = "yyMMdd";
    private final static String DATE_FORMAt_YYYYMMDD = "yyyyMMdd";
    private final static String DATE_FORMAt_YYYYMM = "yyyyMM";

    public Date now() {
        return new Date();
    }

    public Calendar nowCalendar() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        return calendar;
    }

    public static Date makeDate(int day, int month, int year) throws ParseException {
        Locale locale = new Locale("en", "US");
        TimeZone timezone = TimeZone.getDefault();
        Calendar calendar = GregorianCalendar.getInstance(timezone, locale);
        if (month == 2) {
            if (isKabisat(year) && day > 29) {
                calendar.set(year, month, 29);
            } else if (isKabisat(year) && day <= 29) {
                calendar.set(year, month, day);
            } else if (!isKabisat(year) && day > 28) {
                calendar.set(year, month, 28);
            } else if (!isKabisat(year) && day <= 28) {
                calendar.set(year, month, day);
            }
        } else {
            calendar.set(year, month, day);
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        return sdf.parse(sdf.format(calendar.getTime()));
    }

    public static Date makeDateWithoutThrow(int day, int month, int year) {
        try {
            Locale locale = new Locale("en", "US");
            TimeZone timezone = TimeZone.getDefault();
            Calendar calendar = GregorianCalendar.getInstance(timezone, locale);
            month--;
            if (month == 2) {
                if (isKabisat(year) && day > 29) {
                    calendar.set(year, month, 29);
                } else if (isKabisat(year) && day <= 29) {
                    calendar.set(year, month, day);
                } else if (!isKabisat(year) && day > 28) {
                    calendar.set(year, month, 28);
                } else if (!isKabisat(year) && day <= 28) {
                    calendar.set(year, month, day);
                }
            } else {
                calendar.set(year, month, day);
            }
            SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
            return sdf.parse(sdf.format(calendar.getTime()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static Date makeDate2(int day, int month, int year) throws ParseException {
        Locale locale = new Locale("en", "US");
        TimeZone timezone = TimeZone.getDefault();
        Calendar calendar = GregorianCalendar.getInstance(timezone, locale);
        int actualMonth = month - 1;
        if (actualMonth == 2) {
            if (isKabisat(year) && day > 29) {
                calendar.set(year, actualMonth, 29);
            } else if (isKabisat(year) && day <= 29) {
                calendar.set(year, actualMonth, day);
            } else if (!isKabisat(year) && day > 28) {
                calendar.set(year, actualMonth, 28);
            } else if (!isKabisat(year) && day <= 28) {
                calendar.set(year, actualMonth, day);
            }
        } else {
            calendar.set(year, actualMonth, day);
        }
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        return sdf.parse(sdf.format(calendar.getTime()));
    }

    public static String convertLocalDateToStringDDMMMYYYY(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern(DATE_FORMAT_DDMMMYYYY));
    }
    
    public static String convertLocalDateTimeToStringDDMMMYYYY(LocalDateTime date) {
        return date.format(DateTimeFormatter.ofPattern(DATE_FORMAT_DDMMMYYYY));
    }

    public static String convertLocalDateTimeToStringDDMMMYYYYHHmmss(LocalDateTime date) {
        return date.format(DateTimeFormatter.ofPattern(DATE_FORMAT_DDMMMYYYYHHmmss));
    }

    public static String convertDateToString(Date date) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        return sdf.format(date);
    }

    public static String convertDateToStringDDMMMYYYY(Date date) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_DDMMMYYYY);
        return sdf.format(date);
    }

    public static String convertDateToStringYYMMDD(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAt_YYMMDD);
        return sdf.format(date);
    }

    public static int getMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.MONTH) + 1;
    }

    public static int getYear(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.YEAR);
    }

    public static int getDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DATE);
    }

    public static boolean isKabisat(int year) {
        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
            return true;
        }
        return false;
    }

    public static int calculateDayBetweenTwoDate(Date start, Date end) {
        DateTime dt1 = new DateTime(start);
        DateTime dt2 = new DateTime(end);

        int difference = Days.daysBetween(dt1, dt2).getDays();
        if (difference < 0) {
            difference = difference * -1;
        }
        return difference;
    }

    public static int calculateDayBetweenTwoDate2(Date start, Date end) {
        DateTime dt1 = new DateTime(start);
        DateTime dt2 = new DateTime(end);

        return Days.daysBetween(dt1, dt2).getDays();
    }

    public static boolean isAfterBetweenTwoDate(Date firstDate, Date secondDate) {
        DateTime dt1 = new DateTime(firstDate);
        DateTime dt2 = new DateTime(secondDate);
        return dt1.isAfter(dt2);
    }

    public static int calculateMonthBetweenTwoDate(Date start, Date end) {
        DateTime dt1 = new DateTime(start);
        DateTime dt2 = new DateTime(end);

        int difference = Months.monthsBetween(dt1, dt2).getMonths();
        if (difference < 0) {
            difference = difference * -1;
        }
        return difference;
    }

    public static int addWeekForPayment(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, -7);
        return calendar.get(Calendar.DATE);
    }

    public static Date minYear(Integer min) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(DateTimeUtil.getYear(new Date()) - min, DateTimeUtil.getMonth(new Date()), DateTimeUtil.getDay(new Date()));
        return calendar.getTime();

    }

    public static Calendar endThisDay(Date startDate) {
        Calendar normalizedCalendar = Calendar.getInstance();
        normalizedCalendar.setTime(startDate);
        normalizedCalendar.set(Calendar.HOUR_OF_DAY, 23);
        normalizedCalendar.set(Calendar.MINUTE, 59);
        normalizedCalendar.set(Calendar.SECOND, 59);
        normalizedCalendar.set(Calendar.MILLISECOND, 59);

        return normalizedCalendar;
    }

    public static Calendar startThisDay(Date startDate) {
        Calendar normalizedCalendar = Calendar.getInstance();
        normalizedCalendar.setTime(startDate);
        normalizedCalendar.set(Calendar.HOUR_OF_DAY, 0);
        normalizedCalendar.set(Calendar.MINUTE, 0);
        normalizedCalendar.set(Calendar.SECOND, 0);
        normalizedCalendar.set(Calendar.MILLISECOND, 0);

        return normalizedCalendar;
    }

    public static Date firstDateThisMonth() {
        Date today = new Date();
        Calendar normalizedCalendar = Calendar.getInstance();
        normalizedCalendar.setTime(today);
        normalizedCalendar.set(Calendar.HOUR_OF_DAY, 0);
        normalizedCalendar.set(Calendar.MINUTE, 0);
        normalizedCalendar.set(Calendar.SECOND, 0);
        normalizedCalendar.set(Calendar.MILLISECOND, 0);
        normalizedCalendar.set(Calendar.DAY_OF_MONTH, 1);
        return normalizedCalendar.getTime();
    }

    public static Date lastDateThisMonth() {
        Date today = new Date();
        Calendar normalizedCalendar = Calendar.getInstance();
        normalizedCalendar.setTime(today);
        normalizedCalendar.set(Calendar.HOUR_OF_DAY, 0);
        normalizedCalendar.set(Calendar.MINUTE, 0);
        normalizedCalendar.set(Calendar.SECOND, 0);
        normalizedCalendar.set(Calendar.MILLISECOND, 0);
        normalizedCalendar.set(Calendar.DAY_OF_MONTH, normalizedCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return normalizedCalendar.getTime();
    }

    public static Date firstDateThisMonth(Date date) {
        Calendar normalizedCalendar = Calendar.getInstance();
        normalizedCalendar.setTime(date);
        normalizedCalendar.set(Calendar.HOUR_OF_DAY, 0);
        normalizedCalendar.set(Calendar.MINUTE, 0);
        normalizedCalendar.set(Calendar.SECOND, 0);
        normalizedCalendar.set(Calendar.MILLISECOND, 0);
        normalizedCalendar.set(Calendar.DAY_OF_MONTH, 1);
        return normalizedCalendar.getTime();
    }

    public static Date lastDateThisMonth(Date date) {
        Calendar normalizedCalendar = Calendar.getInstance();
        normalizedCalendar.setTime(date);
        normalizedCalendar.set(Calendar.HOUR_OF_DAY, 23);
        normalizedCalendar.set(Calendar.MINUTE, 59);
        normalizedCalendar.set(Calendar.SECOND, 59);
        normalizedCalendar.set(Calendar.MILLISECOND, 59);
        normalizedCalendar.set(Calendar.DAY_OF_MONTH, normalizedCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return normalizedCalendar.getTime();
    }

    public static Date changeDate(Date theDate, int change) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(theDate);
        calendar.add(Calendar.DATE, change);
        return calendar.getTime();
    }

    public static Date changeMonth(Date theDate, int change) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(theDate);
        calendar.add(Calendar.MONTH, change);
        return calendar.getTime();
    }
    
    public static String convertDateToyyyyMM(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        return sdf.format(date);
    }

    public static String convertDateToyyyyMMdd(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        return sdf.format(date);
    }

    public static String convertLocalDateToyyyyMMdd(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern(DATE_FORMAT_DDMMMYYYY));
    }

    public static String convertLocalDateTimeToyyyyMMdd(LocalDateTime dateTime) {
        return dateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAT_DDMMMYYYY));
    }
    
    public static String convertLocalDateTimeToStringYYYYMMDD(LocalDateTime dateTime) {
        return dateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAt_YYYYMMDD));
    }
    
    public static String convertLocalDateTimeToStringYYYYMM(LocalDateTime dateTime) {
        return dateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAt_YYYYMM));
    }
    
    public static String convertLocalDateTimeToyyyyMMddhhmmss(LocalDateTime dateTime) {
        return dateTime.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
    }

    public static String convertDateToyyyyMMddhhmmss(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String formattedDate = sdf.format(date);
        return formattedDate;
    }
    
    public static Date setDate(int date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.set(Calendar.DATE, date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 1);
        return calendar.getTime();
    }
    
    public static int getDayFromDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DAY_OF_MONTH);
    }
    
    public static long diffMonth(Date date1, Date date2) {
        LocalDate localDate1 = date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localDate2 = date2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        long diff = ChronoUnit.MONTHS.between(localDate1, localDate2);
        return diff;
    }

    public static long diffDates(Date date1, Date date2) {
        LocalDate localDate1 = date1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localDate2 = date2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        long diff = ChronoUnit.DAYS.between(localDate1, localDate2);
        return diff;
	}

    public static LocalDate convertToLocalDate(Date value) {
        return value.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static LocalDateTime convertToLocalDateTime(Date value) {
        return value.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static Date toStartHourOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static Date toEndHourOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return calendar.getTime();
    }
    
    public static Date setHourEndOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return calendar.getTime();
    }
}
